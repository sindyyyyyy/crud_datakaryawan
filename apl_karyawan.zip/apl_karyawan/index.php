<!DOCTYPE html>
<html lang="en">
<head>
<title>Data Karyawan</title>
</head>
<body>
<?php
include('class/Database.php');
include('class/Karyawan.php');  
?>
<h1>Aplikasi Data Karyawan</h1>
<hr/>
<p>
<a href="index.php">Home</a>
<a href="index.php?file=karyawan&aksi=tampil">Data Karyawan</a>
<a href="index.php?file=karyawan&aksi=tambah">Tambah Data Karyawan</a>
</p>
<hr/>
<?php
if(isset($_GET['file'])){
include($_GET['file'].'.php');
} else {
echo '<h1 align="center">Selamat Datang</h1>';
}
?>
</body>
</html>