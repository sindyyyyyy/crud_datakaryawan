<?php
// membuat instance
$daftarKaryawan=NEW Karyawan;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h3>Daftar Karyawan</h3>';
$html .='<p>Berikut ini data karyawan</p>';
$html .='<table border="1" width="100%">
<thead>
<th>No.</th>
<th>Id Karyawan</th>
<th>Nama</th>
<th>Tanggal Lahir</th>
<th>L/P</th>
<th>Alamat</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $daftarKaryawan->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisKaryawan){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisKaryawan->id_karyawan.'</td>
<td>'.$barisKaryawan->nama.'</td>
<td>'.$barisKaryawan->tanggal_lahir.'</td>
<td>'.$barisKaryawan->jenis_kelamin.'</td>
<td>'.$barisKaryawan->alamat.'</td>
<td>
<a href="index.php?file=karyawan&aksi=edit&idkaryawan='.$barisKaryawan->id_karyawan.'">Edit</a>
<a href="index.php?file=karyawan&aksi=hapus&idkaryawan='.$barisKaryawan->id_karyawan.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST" action="index.php?file=karyawan&aksi=simpan">';
$html .='<p>ID Karyawan<br/>';
$html .='<input type="text" name="txtId" placeholder="Masukan Id karyawan" autofocus/></p>';
$html .='<p>Nama Lengkap<br/>';
$html .='<input type="text" name="txtNama" placeholder="Masukan Nama Lengkap" size="30" required/></p>';
$html .='<p>Tanggal Lahir<br/>';
$html .='<input type="date" name="txtTanggalLahir" required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtJenisKelamin" value="L"> Laki-laki';
$html .='<input type="radio" name="txtJenisKelamin" value="P"> Perempuan</p>';
$html .='<p>Alamat Lengkap<br/>';
$html .='<textarea name="txtAlamat" placeholder="Masukan alamat lengkap" cols="50" rows="5" required></textarea></p>';
$html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_karyawan'=>$_POST['txtId'],
'nama'=>$_POST['txtNama'],
'tanggal_lahir'=>$_POST['txtTanggalLahir'],
'jenis_kelamin'=>$_POST['txtJenisKelamin'],
'alamat'=>$_POST['txtAlamat']
);
// simpan siswa dengan menjalankan method simpan
$daftarKaryawan->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=karyawan&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data siswa
$karyawan=$daftarKaryawan->detail($_GET['idkaryawan']);
if($karyawan->jenis_kelamin =='L') { $pilihL='checked';
    $pilihP =null; }
    else {
    $pilihP='checked'; $pilihL =null; }
    $html =null;
    $html .='<h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';
    $html .='<form method="POST" action="index.php?file=karyawan&aksi=update">';
    $html .='<p>Nomor Induk Siswa<br/>';
    $html .='<input type="text" name="txtId" value="'.$karyawan->id_karyawan.'" placeholder="Masukan No. Induk" readonly/></p>';
    $html .='<p>Nama Lengkap<br/>';
    $html .='<input type="text" name="txtNama" value="'.$karyawan->nama.'" placeholder="Masukan Nama Lengkap" size="30" required autofocus/></p>';
    $html .='<p>Tanggal Lahir<br/>';
    $html .='<input type="date" name="txtTanggalLahir" value="'.$karyawan->tanggal_lahir.'" required/></p>';
    $html .='<p>Jenis Kelamin<br/>';
    $html .='<input type="radio" name="txtJenisKelamin" value="L" '.$pilihL.'> Laki-laki';
    $html .='<input type="radio" name="txtJenisKelamin" value="P" '.$pilihP.'> Perempuan</p>';
    $html .='<p>Nama Lengkap<br/>';
    $html .='<textarea name="txtAlamat" placeholder="Masukan alamat lengkap" cols="50" rows="5" required>'.$karyawan->alamat.'</textarea></p>';
    $html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'nama'=>$_POST['txtNama'],
        'tanggal_lahir'=>$_POST['txtTanggalLahir'],
        'jenis_kelamin'=>$_POST['txtJenisKelamin'],
        'alamat'=>$_POST['txtAlamat']
        );
        $daftarKaryawan->update($_POST['txtId'],$data);
        echo '<meta http-equiv="refresh" content="0;
        url=index.php?file=karyawan&aksi=tampil">';
        }
        // aksi tambah data
        else if ($_GET['aksi']=='hapus') {
        $daftarKaryawan->hapus($_GET['idkaryawan']);
        echo '<meta http-equiv="refresh" content="0;
        url=index.php?file=karyawan&aksi=tampil">';
        }
        // aksi tidak terdaftar
        else {
        echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
        }
        ?>    